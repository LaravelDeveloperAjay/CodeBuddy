

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit Category</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('categories.index')); ?>"> Back</a>
        </div>
    </div>
</div>

<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<?php echo Form::model($category, ['method' => 'PATCH','route' => ['categories.update', $category->id]]); ?>

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
        <div class="form-group">
            <strong>Name:</strong>
            <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
        <div class="form-group">
            <strong>Parent Category:</strong> 
            <select type="text" name="parent_category_id" class="form-control"> 
                <option value="">Select </option>
                <?php if($categories): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $dash=''; ?>
                        <option value="<?php echo e($categoryitem->id); ?>" <?php if($category->parent_category_id == $categoryitem->id): ?> selected <?php endif; ?>)><?php echo e($categoryitem->name); ?></option>
                        <?php if(count($categoryitem->children)): ?>
                            <?php echo $__env->make('categories.subCategoryList-option',['subcategories' => $categoryitem->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 mb-3 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\codebuddy\resources\views/categories/edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Categories</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('categories.create')); ?>"> Create New Category</a>
        </div>
    </div>
</div>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<table class="table table-bordered mt-5">
 <tr>
   <th>No</th>
   <th>Name</th>
   <th>Parent_Category</th>
   <th>Action</th>
 </tr>
 
<?php $i = 0; ?>
 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e(++$i); ?></td>
    <td><?php echo e($categorie->name); ?></td>
    <td><?php echo e($categorie->parent_category_id); ?></td>
    <td>
       <a class="btn btn-info" href="<?php echo e(route('categories.show',$categorie->id)); ?>">Show</a>
       <a class="btn btn-primary" href="<?php echo e(route('categories.edit',$categorie->id)); ?>">Edit</a>
        <?php echo Form::open(['method' => 'DELETE','route' => ['categories.destroy', $categorie->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </td>
  </tr>
  <?php if(count($categorie->children)): ?>
  <?php $j= 0 ?>
  <?php $__currentLoopData = $categorie->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($i); ?>.<?php echo e(++$j); ?></td>
    <td><?php echo e($child->name); ?></td>
    <td><?php echo e($categorie->name); ?></td>
    <td>
       <a class="btn btn-info" href="<?php echo e(route('categories.show',$child->id)); ?>">Show</a>
       <a class="btn btn-primary" href="<?php echo e(route('categories.edit',$child->id)); ?>">Edit</a>
        <?php echo Form::open(['method' => 'DELETE','route' => ['categories.destroy', $child->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </td>
  </tr> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\codebuddy\resources\views/admindashboard.blade.php ENDPATH**/ ?>